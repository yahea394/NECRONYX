# NECRONYX - Telegram AI Bot

بوت تيليغرام قوي يعمل بالذكاء الاصطناعي (GPT-4) للردود الذكية على المستخدمين.

## التشغيل

1. ثبت المكتبات:

```bash
pip install -r requirements.txt
```

2. أضف متغيرات البيئة:

- `BOT_TOKEN` = توكن البوت من BotFather
- `OPENAI_API_KEY` = مفتاح OpenAI الخاص بك (sk-...)

3. شغّل البوت:

```bash
python main.py
```
