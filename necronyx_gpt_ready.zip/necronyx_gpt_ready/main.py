import os
import logging
import json
from telegram import Update, BotCommand
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes

from src.utils import ask_gpt

BOT_TOKEN = os.getenv("BOT_TOKEN")
if not BOT_TOKEN:
    raise ValueError("يرجى ضبط متغير BOT_TOKEN")

# إعداد التسجيل
logging.basicConfig(format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO)
logger = logging.getLogger(__name__)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("مرحباً بك في NECRONYX! أنا مساعدك الذكي، أرسل أي سؤال أو أمر.")

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    help_text = "/start - بدء البوت\n/help - المساعدة\nأرسل أي رسالة وسأرد عليك بالذكاء الاصطناعي!"
    await update.message.reply_text(help_text)

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_msg = update.message.text
    await update.message.chat.send_action(action="typing")
    reply = await ask_gpt(user_msg)
    await update.message.reply_text(reply)

def main():
    app = ApplicationBuilder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(MessageHandler(filters.TEXT & (~filters.COMMAND), handle_message))

    app.bot.set_my_commands([
        BotCommand("start", "ابدأ البوت"),
        BotCommand("help", "مساعدة")
    ])

    logger.info("تم تشغيل NECRONYX")
    app.run_polling()

if __name__ == "__main__":
    main()
