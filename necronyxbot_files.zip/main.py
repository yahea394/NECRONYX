import telebot

TOKEN = "PUT-YOUR-TOKEN-HERE"
bot = telebot.TeleBot(TOKEN)

@bot.message_handler(commands=['start', 'help'])
def send_welcome(message):
    bot.reply_to(message, "مرحبا بك في بوت Necronyx الذكي. كيف يمكنني مساعدتك؟")

@bot.message_handler(func=lambda message: True)
def echo_all(message):
    bot.reply_to(message, "جارٍ تحليل سؤالك باستخدام الذكاء الاصطناعي...")

bot.infinity_polling()
